#!/usr/bin/python

import os

os.system("git submodule update --init")
